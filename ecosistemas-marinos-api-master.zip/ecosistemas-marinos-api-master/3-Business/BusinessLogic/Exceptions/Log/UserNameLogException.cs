﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Exceptions.Log
{
    public  class UserNameLogException : LogException
    {
        public UserNameLogException() { }

        public UserNameLogException(string? message) : base(message)
        {
        }
    }
}
