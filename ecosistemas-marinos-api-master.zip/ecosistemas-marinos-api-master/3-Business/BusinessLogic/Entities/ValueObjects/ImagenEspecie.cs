﻿using BusinessLogic.InterfacesDeDominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Entities
{
    public class ImagenEspecie
    {
        public string Nombre { get; set; }
        public int EspecieId { get; set; }
    }
}
