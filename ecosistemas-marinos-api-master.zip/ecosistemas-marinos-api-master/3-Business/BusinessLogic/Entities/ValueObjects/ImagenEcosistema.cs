﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.InterfacesDeDominio;


namespace BusinessLogic.Entities
{
    public class ImagenEcosistema
    {
        public string Nombre { get; set; }
        public int EcosistemaId { get; set; }
    }
}
