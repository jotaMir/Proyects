﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.DTO
{
    public class AsignarEcosistemaDto
    {
        public int EspecieId { get; set; }
        public int EcosistemaId { get; set; }
    }
}
