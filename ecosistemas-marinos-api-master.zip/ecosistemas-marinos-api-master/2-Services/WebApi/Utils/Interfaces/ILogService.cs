﻿namespace WebApi.Utils.Interfaces
{
    public interface ILogService
    {
        public void CreateLog(int idEntidad, string tipoEntidad);
    }
}
