﻿namespace WebApi.Utils.Interfaces
{
    public interface IUserNameService
    {
        string GetActualUsername();
    }
}
