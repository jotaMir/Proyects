﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Exceptions.Log
{
    public class LogException : DomainException
    {
        public LogException() { }

        public LogException(string? message) : base(message)
        {
        }
    }
}
