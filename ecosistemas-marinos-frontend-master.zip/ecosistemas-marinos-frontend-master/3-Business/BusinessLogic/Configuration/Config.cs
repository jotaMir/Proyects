﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Configuration
{
    public static class Config
    {
        public static int DescripcionMaximo { get; set; }
        public static int DescripcionMinimo { get; set; }
        public static int NombreMinimo { get; set; }
        public static int NombreMaximo { get; set; }
    }
}
