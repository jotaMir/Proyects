﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Configuration
{
    public class ApiConf
    {
        public string BaseUrl { get; set; }
    }
}
