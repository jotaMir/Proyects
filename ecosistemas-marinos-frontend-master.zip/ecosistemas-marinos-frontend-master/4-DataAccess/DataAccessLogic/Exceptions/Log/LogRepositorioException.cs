﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLogic.Exceptions.Log
{
    public class LogRepositorioException :RepositorioException
    {
        public LogRepositorioException()
        {
            
        }

        public LogRepositorioException(string? message) : base(message)
        {
        }
    }
}
